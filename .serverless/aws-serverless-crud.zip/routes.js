// import express from "express";
// import {
//   createUser,
//   getUserById,
//   getAllUsers,
//   updateUser,
//   deleteUserById,
// } from "./userAPI.js";

// const router = express.Router();

// // Create User
// router.route("/users").post(createUser);
// // router.route("/users/:id").get(getUserById);
// // router.route("/users").get(getAllUsers);
// // router.route("/users").put(updateUser);
// // router.route("/users/:id").delete(deleteUserById);

// export default router;
